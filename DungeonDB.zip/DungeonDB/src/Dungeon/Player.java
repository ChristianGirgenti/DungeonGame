package Dungeon;

public class Player {
	
	int health = 40;
	
	public int getHealth()
	{
		return health;
	}
	
	public void setHealth (int newHealth)
	{
		this.health=newHealth;
	}
	
	
	
}
